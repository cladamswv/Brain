# Glorp v0.16.21 voice-production staging

The **23 new scripted lines are NOT recordings yet**. The existing ten original Glorp MP3 files are preserved. The voice service declined recording via the current connected plan, so **no substitute synthetic or robotic narrator was used**.

Approved voice direction: Grungle (raspy animated creature). 11 intro variations and 12 reaction lines are listed in `GLORP_VOICE_PRODUCTION_v0.16.21.json` with exact texts and filenames.

When authentic new Grungle MP3s become available, put them in a directory named using the exact identifiers in the JSON (for example `intro-01.mp3` or `reaction-01.mp3`) and run:

```bash
node scripts/import-glorp-recordings.mjs /path/to/recorded-mp3-folder
npm test
bash scripts/codespaces-build.sh
```

The importer accepts existing MP3 files only, checks file headers and sizes, preserves partial batches, and enables only the phrases with actual local audio. It never accesses online TTS. All recordings will be embedded in the APK and offline web cache at the next build.

Current build continues to play the ten original Glorp recordings, with pending dialogue remaining text-only. All games remain mobile-first and offline.

# Professor Brainrot Academy v0.16.21

A fully offline, portrait-first Android learning game, with Brain Battle, multiple mini-games, guided text tutorials, and student progress tracking. All original Glorp recordings preserved.

**Start here:** [CODESPACES_START_HERE.md](CODESPACES_START_HERE.md)

**Audit:** [MOBILE_AND_AUDIO_QA_v0.16.21.md](MOBILE_AND_AUDIO_QA_v0.16.21.md)

Development: `npm ci && npm test`

Android build in Codespaces: `bash scripts/codespaces-build.sh` (requires Java 21 and Android SDK; the script prepares them)

Synthetic narration has been intentionally removed. Tutorials remain text and practice questions; unrecorded Glorp dialogue is silent text, not revoiced.

## v0.16.21 Grungle voice production staging
The 23 new lines are scripted but not recorded. See `VOICE_PRODUCTION_STATUS_v0.16.21.md` and `GLORP_VOICE_PRODUCTION_v0.16.21.json`. Existing authentic Glorp recordings are bundled and the original mobile/offline gameplay remains unchanged.

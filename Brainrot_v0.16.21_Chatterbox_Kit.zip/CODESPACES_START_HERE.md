# Professor Brainrot Academy v0.16.21 | Mobile + Real Glorp Audio

## Build from your phone in GitHub Codespaces

Upload **Brainrot_v0.16.21.zip** to your Codespaces Explorer. Put it in the top Brainrot folder or in `scripts/`.
Open Terminal and paste:

```bash
set -e
cd /workspaces/Brainrot
ZIP=$(find . -maxdepth 3 -name 'Brainrot_v0.16.21.zip' -type f -print -quit)
test -n "$ZIP" || { echo 'Upload Brainrot_v0.16.21.zip first'; exit 1; }
unzip -t "$ZIP"
unzip -oq "$ZIP" -d .
bash scripts/codespaces-build.sh
```

If your Codespace has another repository name, omit `cd /workspaces/Brainrot` and run from that repository's root.

The APK is generated at:

`artifacts/Brainrot_Academy_v0.16.21-debug.apk`

Right-click the APK in the Explorer panel to **Download**, or get it from the successful **GitHub Actions** workflow after committing and pushing source.

**Keep existing app installed** and try installing the updated APK over it. If Android reports a signing mismatch, back up progress before uninstalling; the old debug signing key might differ.

## What this release changes
- Ten original Grungle/Glorp voice MP3s are preserved unchanged.
- Synthetic tutorial/narration clips and unused reference file are removed.
- Every tutorial is still readable and interactive without internet.
- Old synthetic audio remnants are cleaned from existing Codespaces before building.
- Mobile-first layout uses stacked answer choices, normal-flow help, responsive touch controls.
- Faster startup via lazy audio loading and deferred offscreen image decoding.

## Validation
Run `npm test`. Source tests do not replace on-device Android checks. Build tools require internet to install, but the resulting game content is bundled for offline use.

# Android APK Builds for v0.16.21

For GitHub Codespaces, see [CODESPACES_START_HERE.md](CODESPACES_START_HERE.md).

Run `bash scripts/codespaces-build.sh`. Expected output: `artifacts/Brainrot_Academy_v0.16.21-debug.apk`.

For GitHub Actions, commit the extracted source to `main`, then run the **Build Android APK** workflow or push changes. Download the APK from the workflow's **Artifacts** section after it succeeds.

Java 21 is required; the Codespaces build script will select or install it.

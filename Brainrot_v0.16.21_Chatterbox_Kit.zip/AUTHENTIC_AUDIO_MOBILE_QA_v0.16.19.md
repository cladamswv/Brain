# Brainrot Academy v0.16.19: Original Glorp + Mobile QA

- Only **10 preserved original Grungle/Glorp performance files** are permitted to play as Glorp character speech. Byte-for-byte SHA-256 verified against the oldest fully preserved archive, and verified again by tests after extraction.
- No synthetic Glorp clips, AI stand-ins, speechSynthesis calls, or remote audio files. All Glorp lines lacking an exact original recording remain **written-only** with independent character sound effects. The 12 later new dialogues still need original recordings if we want them spoken.
- Added a **Hear the real Glorp voice** button in parent settings for a one-tap spot check of the original `POTATO!` recording.
- **Tutorial narration is a separate setting**, disabled by default to ensure the default experience contains no synthetic spoken dialogue. Optionally turning it on plays the existing locally bundled *separate synthetic tutorial guide voice*, not Glorp. Text tutorials always remain available offline.
- Keeps portrait-first single-column battle, scrollable question/answers, no covering help button, 44px+ action targets, safe-area support, and phone-sized activity screens from v0.16.18.
- Same app ID and storage keys; version code 1619. Existing installation can update when the debug signing keys match.
- Java 21 Codespaces builder remains available at `bash scripts/codespaces-build.sh`. Full compilation and physical device behavior need testing in Codespaces/on a phone.

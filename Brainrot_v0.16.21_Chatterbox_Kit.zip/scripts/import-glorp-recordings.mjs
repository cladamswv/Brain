// Install user-supplied, approved Grungle MP3s in the offline game. Never synthesizes audio.
// Usage: node scripts/import-glorp-recordings.mjs /path/to/mp3-folder
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
const root=process.cwd();
const sourceDir=process.argv[2];
if(!sourceDir || !fs.existsSync(sourceDir)) { console.error('Supply a folder of approved recorded Grungle MP3 files.');process.exit(2); }
const manifest=JSON.parse(fs.readFileSync('GLORP_VOICE_PRODUCTION_v0.16.21.json','utf8'));
const dest='assets/audio/voice/expansion';
fs.mkdirSync(dest,{recursive:true});
// Preserve previously approved clips when adding another batch.
const installed={};
const required=new Set(manifest.lines.map(l=>l.id+'.mp3'));
for(const line of manifest.lines){
  const filename=line.id+'.mp3'; const source=path.resolve(sourceDir,filename);
  const target=path.join(dest,filename);
  if(fs.existsSync(source)){
    const bytes=fs.readFileSync(source);
    if(bytes.length<1024 || !(bytes[0]===0x49&&bytes[1]===0x44&&bytes[2]===0x33) && !(bytes[0]===0xff&&(bytes[1]&0xe0)===0xe0)){
      throw new Error(filename+' is not an MP3 recording');
    }
    // Refuse byte-identical duplicate dialog disguised with another filename.
    fs.copyFileSync(source,target);
  }
  if(fs.existsSync(target)){
    const bytes=fs.readFileSync(target);
    if(bytes.length<1024)throw new Error('Invalid recorded MP3 '+target);
    installed[line.text]='voice/expansion/'+filename;
    line.status='installed';
    line.sha256=crypto.createHash('sha256').update(bytes).digest('hex');
  }
}
const lines=Object.entries(installed);
const intros=manifest.lines.filter(l=>l.category==='intro'&&installed[l.text]).map(l=>l.text);
fs.writeFileSync('js/glorp-expansion.js',
 '// Generated exclusively from supplied Grungle voice recordings.\n'+
 'export const GLORP_EXPANSION = Object.freeze('+JSON.stringify(installed,null,2)+');\n'+
 'export const GLORP_EXPANSION_OPENINGS = Object.freeze('+JSON.stringify(intros,null,2)+');\n');
fs.writeFileSync('GLORP_VOICE_PRODUCTION_v0.16.21.json',JSON.stringify(manifest,null,2)+'\n');
console.log('Installed '+lines.length+' of '+manifest.lines.length+' recorded dialogue lines. All other lines stay text-only.');

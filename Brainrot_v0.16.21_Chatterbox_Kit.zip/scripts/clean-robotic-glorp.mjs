/** Remove superseded synthetic narration and reconstructed voices during upgrades.
 * Keep the ten original Glorp performances and all game SFX/music intact.
 * Also runs before bundling when the ZIP is unpacked over an older Codespace.
 */
import fs from 'node:fs';
import path from 'node:path';
const root=process.cwd();
for(const folder of ['intro-reconstruction','offline-reconstruction']){
  fs.rmSync(path.join(root,'assets','audio','voice',folder),{recursive:true,force:true});
}

// Older installs may still have these audio files after a new ZIP is extracted.
// Remove them before regenerating the offline manifest and Android web bundle.
for(const folder of ['assets/audio/tutorial','assets/audio/reference',
                     'www/assets/audio/tutorial','www/assets/audio/reference']){
  fs.rmSync(path.join(root,folder),{recursive:true,force:true});
}

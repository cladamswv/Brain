#!/usr/bin/env bash
# Free, local Chatterbox voice cloning (CPU Nano default). No paid cloud API.
set -euo pipefail
cd "$(dirname "$0")/.."
mode="${1:-sample}"
if [ "$#" -gt 0 ]; then shift; fi
if [[ "$mode" == "install" ]]; then
  [[ -d voice_previews/chatterbox ]] || { echo 'Create voice samples first.'; exit 2; }
  node scripts/import-glorp-recordings.mjs voice_previews/chatterbox
  if [[ ! -d node_modules ]]; then npm ci; fi
  npm test
  echo 'Approved recordings imported. Run bash scripts/codespaces-build.sh to build APK.'
  exit 0
fi
if [[ "$mode" == 'reference' ]]; then
  python3 scripts/generate-glorp-chatterbox.py reference
  exit 0
fi
if [[ "$mode" != 'sample' && "$mode" != 'all' ]]; then
  echo 'Usage: bash scripts/chatterbox-glorp.sh sample | all | install'; exit 2
fi
command -v ffmpeg >/dev/null || { echo 'Install ffmpeg first: sudo apt-get update && sudo apt-get install -y ffmpeg'; exit 2; }
# Build isolated Python environment without disturbing the Android/Node setup.
if ! command -v uv >/dev/null 2>&1; then
  if [[ ! -x "$HOME/.local/share/brainrot-uv-bootstrap/bin/uv" ]]; then
    python3 -m venv "$HOME/.local/share/brainrot-uv-bootstrap"
    "$HOME/.local/share/brainrot-uv-bootstrap/bin/python" -m pip install 'uv>=0.8'
  fi
  export PATH="$HOME/.local/share/brainrot-uv-bootstrap/bin:$PATH"
fi
if [[ ! -x .venv-glorp/bin/python ]]; then
  uv python install 3.11
  uv venv --python 3.11 .venv-glorp
fi
if ! .venv-glorp/bin/python -c 'from chatterbox.tts_turbo import ChatterboxTurboTTS' 2>/dev/null; then
  echo 'Installing CPU PyTorch and open-source Chatterbox into .venv-glorp ...'
  uv pip install --python .venv-glorp/bin/python 'torch==2.6.0+cpu' 'torchaudio==2.6.0+cpu' --index-url https://download.pytorch.org/whl/cpu
  uv pip install --python .venv-glorp/bin/python 'chatterbox-tts==0.1.7'
fi
# Select CPU Nano by default; use CHATTERBOX_MODEL=turbo only on GPU-equipped machines.
.venv-glorp/bin/python scripts/generate-glorp-chatterbox.py "$mode" --model "${CHATTERBOX_MODEL:-nano}" "$@"

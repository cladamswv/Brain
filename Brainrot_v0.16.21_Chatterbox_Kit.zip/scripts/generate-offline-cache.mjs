import fs from 'node:fs';
import path from 'node:path';
const root=process.cwd();
const walk=(p)=>fs.readdirSync(path.join(root,p),{withFileTypes:true})
  .flatMap(e=>e.isDirectory()?walk(path.posix.join(p,e.name)):[path.posix.join(p,e.name)]);
const files=['./','index.html','styles.css','mobile-first.css','manifest.webmanifest','sw.js',...walk('js'),...walk('assets')];
const entries=[...new Set(files)].sort((a,b)=>a==='./'?-1:b==='./'?1:a.localeCompare(b));
for(const item of entries){
  if(item==='./')continue;
  if(!fs.statSync(path.join(root,item)).isFile())throw new Error(`Missing bundled asset ${item}`);
}
const file=path.join(root,'sw.js');
const source=fs.readFileSync(file,'utf8');
const data='const ASSETS=[\n'+entries.map(f=>`  ${"'"+(f.startsWith('./')?f:'./'+f)+"'"}`).join(',\n')+'\n];';
const output=source.replace(/const ASSETS=\[[\s\S]*?\];/,data);
if(output===source && !source.includes(data))throw new Error('Cannot replace offline asset manifest');
fs.writeFileSync(file,output);
console.log(`Offline cache generated: ${entries.length} local paths`);

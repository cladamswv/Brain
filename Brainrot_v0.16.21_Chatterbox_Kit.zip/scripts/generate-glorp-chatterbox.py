#!/usr/bin/env python3
"""Generate voice samples with actual open-source Chatterbox Nano/Turbo.

The reference WAV is made entirely from already-bundled original Glorp recordings.
Audio is staged for listening before it is imported into the game.
No paid TTS API or cloud inference service is used.
"""
from __future__ import annotations
import argparse
import json
import pathlib
import shutil
import subprocess
import sys
import tempfile

ROOT = pathlib.Path(__file__).resolve().parent.parent
MANIFEST = ROOT / 'GLORP_VOICE_PRODUCTION_v0.16.21.json'
VOICE_DIR = ROOT / 'assets' / 'audio' / 'voice'
OUT = ROOT / 'voice_previews' / 'chatterbox'
REF = OUT / 'glorp_reference.wav'
REFERENCE_FILES = (
    'glorp-wins.mp3', 'watch-videos.mp3',
    'stop-knowing-math.mp3', 'game-cheating.mp3', 'question-rigged.mp3',
)

def command(args):
    print('+', ' '.join(map(str, args)), flush=True)
    subprocess.run(list(map(str, args)), check=True)

def make_reference():
    if not shutil.which('ffmpeg'):
        raise SystemExit('ffmpeg is needed. In Codespaces: sudo apt-get update && sudo apt-get install -y ffmpeg')
    OUT.mkdir(parents=True, exist_ok=True)
    files = [VOICE_DIR / n for n in REFERENCE_FILES]
    for f in files:
        if not f.is_file(): raise SystemExit('Missing original Glorp recording: ' + str(f))
    with tempfile.TemporaryDirectory() as t:
        concat = pathlib.Path(t) / 'glorp-inputs.txt'
        concat.write_text(''.join("file '" + str(f).replace("'", "'\\''") + "'\n" for f in files))
        command(['ffmpeg', '-hide_banner', '-loglevel', 'error', '-y', '-f', 'concat', '-safe', '0', '-i', concat,
                 '-t', '10', '-ar', '24000', '-ac', '1', '-c:a', 'pcm_s16le', REF])
    print('Original Glorp reference prepared:', REF)
    return REF

def main():
    p = argparse.ArgumentParser(description='Create Glorp voice lines locally using Chatterbox')
    p.add_argument('mode', choices=['reference', 'sample', 'all'], help='reference only, sample first line, or all 23 lines')
    p.add_argument('--model', choices=['nano', 'turbo'], default='nano', help='Nano works on CPU, Turbo best with GPU')
    p.add_argument('--device', choices=['auto', 'cpu', 'cuda'], default='auto')
    p.add_argument('--sample-id', default='intro-01', help='Manifest ID for sample')
    args = p.parse_args()
    ref=make_reference()
    if args.mode == 'reference': return
    try:
        import torch
        import torchaudio as ta
        from chatterbox.tts_turbo import ChatterboxTurboTTS
    except ImportError as exc:
        raise SystemExit('Missing Python model dependencies. Run: bash scripts/chatterbox-glorp.sh sample') from exc
    device = ('cuda' if torch.cuda.is_available() else 'cpu') if args.device == 'auto' else args.device
    if device=='cuda' and not torch.cuda.is_available():
        raise SystemExit('CUDA was requested but is unavailable. Try --device cpu.')
    print(f'Loading Chatterbox {args.model} on {device}; first run downloads open model weights.', flush=True)
    model = ChatterboxTurboTTS.from_pretrained(device=device, nano=(args.model == 'nano'))
    manifest = json.loads(MANIFEST.read_text())
    if args.mode=='sample':
        wanted=[x for x in manifest['lines'] if x['id']==args.sample_id]
        if not wanted: raise SystemExit('Unknown sample ID ' + args.sample_id)
    else: wanted=manifest['lines']
    for ix, line in enumerate(wanted, 1):
        output=OUT / (line['id']+'.mp3')
        if output.exists() and output.stat().st_size > 2048:
            print(f'[{ix}/{len(wanted)}] Existing recording kept: {output.name}')
            continue
        print(f'[{ix}/{len(wanted)}] Recording {line["id"]}: {line["text"]}', flush=True)
        with torch.inference_mode():
            wav=model.generate(line['text'], audio_prompt_path=str(ref))
        with tempfile.TemporaryDirectory() as t:
            tempwav=pathlib.Path(t) / 'generated.wav'
            ta.save(str(tempwav), wav.cpu(), model.sr)
            command(['ffmpeg','-hide_banner','-loglevel','error','-y','-i',tempwav,
                     '-c:a','libmp3lame','-b:a','96k','-ar','24000','-ac','1',output])
        if not output.is_file() or output.stat().st_size <= 2048:
            raise SystemExit('Failed to create playable MP3: ' + str(output))
        print('Saved', output, f'({output.stat().st_size:,} bytes)')
    print('Done. PREVIEWS ONLY, not imported. Listen first, then run: bash scripts/chatterbox-glorp.sh install')

if __name__ == '__main__': main()

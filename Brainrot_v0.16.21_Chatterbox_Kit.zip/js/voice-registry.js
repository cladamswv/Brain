import {GLORP_EXPANSION, GLORP_EXPANSION_OPENINGS} from './glorp-expansion.js';
export const CHARACTER_VOICES = Object.freeze({
  professor: Object.freeze({
    id: 'professor-brainrot',
    displayName: 'Professor Brainrot',
    role: 'teacher',
    familyRole: 'older-brother',
    sibling: 'glorp',
    voiceDirection: 'Approved custom Option 1: warm, educated, eccentric, theatrical, patient, dryly amused.',
    status: 'speech-bubble-only',
    provider: 'none',
    referenceArchive: null, // Unused voice reference excluded from offline release
    localBundleReady: false,
    finalVoiceRequired: false
  }),
  glorp: Object.freeze({
    id: 'glorp',
    displayName: 'Glorp',
    role: 'comic-foil',
    familyRole: 'younger-brother',
    sibling: 'professor',
    voiceDirection: 'Grungle: raspy animated creature, smug, bratty, expressive, comic meltdown energy.',
    status: 'original-bundled-voice',
    provider: 'runway',
    providerVoice: 'Grungle',
    localBundleReady: true,
    finalVoiceRequired: true
  })
});

// STRICT CHARACTER VOICE CONTRACT:
// Glorp may speak only when we have a matching, original performance.
// Other jokes still appear as written dialogue, accompanied by local SFX.
// Never substitute a different recorded phrase or synthetic TTS for Glorp.
export const GLORP_UNRECORDED_SCRIPTS = Object.freeze([
  'Easy. Obviously.', 'Beginner stuff. I could do this in my sleep.',
  'Told you. Glorp genius.', 'Okay, that one barely counts.',
  'Professor, your questions are suspicious.', 'Stop knowing things!',
  'Who wrote these questions?!', 'This game is cheating!',
  'Professor! Make them less smart!', 'No! No! No! I demand a rematch!',
  'I was going to say that.', 'Fine. Maybe you are a little smart.'
]);
// New lines are enabled ONLY after approved MP3s are imported locally.
export const GLORP_PRODUCTION_LINES = GLORP_EXPANSION;
export const GLORP_OFFLINE_RECONSTRUCTIONS = GLORP_PRODUCTION_LINES;
export const GLORP_LOCAL_FALLBACKS = Object.freeze({});

// The launch greeting chooses one existing REAL Glorp voice clip, not a
// synthesized script or a device TTS engine. Spoken text matches the clip.
export const GLORP_AUTHENTIC_OPENINGS = Object.freeze([
  'POTATO!',
  'HOTDOG!',
  "GRANDPA'S WI-FI!",
  "Let's watch videos instead!",
  'MATH IS BROKEN!',
  'HAHA! GLORP WINS!',
]);

// Professor is intentionally text-only in v0.11.1. The approved Option 1 sample
// is archived for possible future use, but spelling has no pronunciation audio.
export const LEGACY_GLORP_FILES = Object.freeze({
  'POTATO!': 'voice/potato.mp3',
  'HOTDOG!': 'voice/hotdog.mp3',
  "GRANDPA'S WI-FI!": 'voice/grandpas-wifi.mp3',
  'STOP KNOWING MATH!': 'voice/stop-knowing-math.mp3',
  'HAHA! GLORP WINS!': 'voice/glorp-wins.mp3',
  'THIS GAME IS CHEATING!': 'voice/game-cheating.mp3',
  'WHAT?!': 'voice/what-no.mp3',
  'WHAT?! NO!': 'voice/what-no.mp3',
  "Let's watch videos instead!": 'voice/watch-videos.mp3',
  'That question was rigged!': 'voice/question-rigged.mp3',
  'MATH IS BROKEN!': 'voice/math-broken.mp3'
});

export function getCharacterVoiceSource(speaker, text) {
  if (speaker === 'glorp') {
    const expansionFile=GLORP_EXPANSION[text];
    if (expansionFile) return {type:'local-legacy',file:expansionFile,speaker,text,authentic:true};
    const legacyFile=LEGACY_GLORP_FILES[text];
    if (legacyFile) return {type:'local-legacy',file:legacyFile,speaker,text,authentic:true};
  }
  // Professor intentionally remains text-only in the original game design.
  return null;
}

export function isProductionGlorpLine(text) {
  return Boolean(LEGACY_GLORP_FILES[text] || GLORP_EXPANSION[text]);
}

export const GLORP_NEW_OPENINGS = GLORP_EXPANSION_OPENINGS;

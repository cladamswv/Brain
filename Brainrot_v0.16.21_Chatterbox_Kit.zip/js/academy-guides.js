/* Offline Academy help and guided mini-lessons. Independent of saved gameplay progress. */
export const GUIDES = Object.freeze({
  activityScreen: {title:'WELCOME TO THE ACADEMY',icon:'🧠',steps:[
    ['Pick your adventure','Brain Battle is a question showdown. Pizza Party practices math. Milkshake Machine practices spelling. Logic Lab has five reasoning games.'],
    ['Choose a grade','The selected grade controls the learning difficulty. You can change it anytime from Home.'],
    ['Learn first, then play','Tap HOW TO PLAY in any game for its rules. Time, Calendar, and Grammar have optional practice lessons before you jump into a challenge.']]},
  subjectScreen: {title:'CHOOSE A SCHOOL SUBJECT',icon:'📚',steps:[
    ['Choose what to practice','Pick Math, Time, Calendar, Reading, Grammar, or any of the other subjects. Mixed practice pulls from several subjects.'],
    ['Take a warm-up','Tap a lesson card below for a short explanation, a worked example, and a practice problem. Lessons do not spend lives or change your grades.']]},
  battleScreen: {title:'BRAIN BATTLE',icon:'⚔️',steps:[
    ['Read the question','Choose an answer or use the interaction shown. Different subjects may use different answer controls.'],
    ['Make Glorp rage','Correct answers power your attack. Wrong answers give Glorp a chance to fight back, but each mistake includes an explanation.'],
    ['Pause any time','Use the pause button to restart, leave, or resume. Review the explanation after each answer before continuing.']]},
  logicHubScreen: {title:'LOGIC LAB',icon:'🧩',steps:[
    ['Choose a lab','Lost & Found, Pattern Lab, Shape Lab, Robot Rescue, and Slime Sweeper all exercise reasoning.'],
    ['Start on Normal','Normal gives you more hints and Brain Power; Hard and Extreme are tougher. Academic grades are tracked separately.']]},
  logicLabScreen: {title:'LOST & FOUND',icon:'🎒',steps:[
    ['Find the school supplies','Each row and column gives clues about where hidden supplies might be.'],
    ['Mark or search','Mark an impossible square with an X. Switch to Search for a one-tap reveal, or double-tap a square in Mark mode.'],
    ['Use logic first','A wrong search costs Brain Power. Use the hint button when you are stuck.']]},
  patternLabScreen: {title:'PATTERN LAB',icon:'🔢',steps:[
    ['Find the rule','Look at what changes from one symbol or number to the next.'],
    ['Predict the missing piece','Choose the item that continues the rule. Pay attention to repeats, rotation, or growing gaps.'],
    ['Keep experimenting','Try a different pattern if your first idea does not fit every step.']]},
  shapeLabScreen: {title:'SHAPE LAB',icon:'🔷',steps:[
    ['Inspect the target','Look for open squares and the shapes available to you.'],
    ['Rotate and place','Rotate pieces, then fit them on the board without overlaps.'],
    ['Think ahead','Start with corners or awkward gaps. Reset if you get stuck.']]},
  robotLabScreen: {title:'ROBOT RESCUE',icon:'🤖',steps:[
    ['Plan a route','Build a small program with robot commands to reach the goal.'],
    ['Run your commands','Press RUN to test the route. Use Undo or Clear to change the plan.'],
    ['Save power','Avoid hazards and unnecessary moves to earn more stars.']]},
  slimeLabScreen: {title:'SLIME SWEEPER',icon:'🟢',steps:[
    ['Read the numbers','Each revealed number shows how many slime blobs touch that square, including diagonals.'],
    ['Mark proven slime','Use MARK SLIME when a clue proves a hidden square contains slime. Do not guess.'],
    ['Reveal what is safe','Switch to REVEAL to open safe squares. Clear marks or use a hint if needed. Every stage has a logical solution.']]},
  partsSpeechScreen: {title:'PARTS OF SPEECH COURSE',icon:'📖',steps:[
    ['Learn the eight jobs of words','Start with Nouns, Verbs, Adjectives, Pronouns, Adverbs, Prepositions, Conjunctions, and Interjections.'],
    ['Read the explanation','Each lesson includes examples and a sentence to study before its practice questions.'],
    ['Finish the course','Track your completed lessons and take the Mixed Mastery challenge whenever you are ready.']]}
});

export const LESSONS = Object.freeze({
  time: {title:'CLOCK SMARTS',icon:'🕒',steps:[
    {title:'Hour hand versus minute hand',text:'The short hand points to the hour. The long hand points to the minutes. When the long hand is on 12, the time is exactly on the hour.',example:'Short hand: 3. Long hand: 12. Time: 3:00.'},
    {title:'Count minutes by fives',text:'The long hand counts 5 minutes for every number. On 3 is 15 minutes, on 6 is 30 minutes, on 9 is 45 minutes.',example:'Long hand on 6 means 30 minutes past the hour: 4:30.'},
    {title:'Elapsed time',text:'To find how much time passes, count forward. From 2:15 to 2:45 is 30 minutes. From 9:00 to 10:30 is 1 hour and 30 minutes.',example:'If class starts at 1:20 and ends at 1:50, it lasts 30 minutes.'}
  ],question(grade){return Number(grade)<=2
    ? {prompt:'The minute hand points to 6. How many minutes past the hour?',choices:['6 minutes','15 minutes','30 minutes','60 minutes'],answer:'30 minutes',explanation:'Each clock number stands for 5 minutes. Six times five equals 30.'}
    : Number(grade)<=4
    ? {prompt:'Practice begins at 3:15 and lasts 45 minutes. When does it end?',choices:['3:45','4:00','4:15','5:00'],answer:'4:00',explanation:'Count forward 45 minutes from 3:15: 15 to 30 to 45 to 4:00.'}
    : {prompt:'A bus leaves at 10:35 a.m. and arrives at 12:10 p.m. How long was the ride?',choices:['1 hour 15 minutes','1 hour 35 minutes','2 hours 25 minutes','95 hours'],answer:'1 hour 35 minutes',explanation:'10:35 to 11:35 is one hour; then 35 more minutes brings us to 12:10.'};}},
  calendar: {title:'CALENDAR QUEST',icon:'📅',steps:[
    {title:'Seven days in a week',text:'Sunday, Monday, Tuesday, Wednesday, Thursday, Friday, Saturday. After Saturday comes Sunday again.',example:'The day after Wednesday is Thursday.'},
    {title:'Twelve months in a year',text:'January, February, March, April, May, June, July, August, September, October, November, December.',example:'April comes after March and before May.'},
    {title:'Count dates and leap years',text:'September, April, June, and November have 30 days. February has 28 days in most years and 29 in leap years. The other months have 31.',example:'2028 is a leap year; February 2028 has 29 days.'}
  ],question(grade){return Number(grade)<=2
    ? {prompt:'Which month comes right after June?',choices:['April','May','July','September'],answer:'July',explanation:'The order goes May, June, July, August.'}
    : Number(grade)<=4
    ? {prompt:'What day comes 3 days after Tuesday?',choices:['Thursday','Friday','Saturday','Monday'],answer:'Friday',explanation:'Wednesday is 1, Thursday is 2, and Friday is 3.'}
    : {prompt:'How many days does February have in the year 2028?',choices:['28','29','30','31'],answer:'29',explanation:'2028 is divisible by 4 and is not a century year, so it is a leap year.'};}},
  grammar: {title:'GRAMMAR WARM-UP',icon:'✏️',steps:[
    {title:'Nouns and verbs',text:'A noun names a person, place, thing, or idea. A verb tells what happens or shows a state of being.',example:'In “Glorp runs,” Glorp is a noun and runs is a verb.'},
    {title:'Words that describe',text:'Adjectives describe nouns, such as funny, yellow, or enormous. Adverbs can describe verbs, such as slowly, quietly, or quickly.',example:'In “The speedy robot moves carefully,” speedy is an adjective; carefully is an adverb.'},
    {title:'Write a complete thought',text:'A sentence begins with a capital letter and usually ends with a period, question mark, or exclamation point. Subject and verb should agree.',example:'Correct: “The robots are dancing.” Not “The robots is dancing.”'}
  ],question(grade){return Number(grade)<=2
    ? {prompt:'Which word is a verb in “Glorp jumps high”?',choices:['Glorp','jumps','high','the'],answer:'jumps',explanation:'Jumps tells what Glorp does. That is the action verb.'}
    : Number(grade)<=4
    ? {prompt:'Which word is the adverb in “The robot moves carefully”?',choices:['robot','moves','carefully','the'],answer:'carefully',explanation:'Carefully tells how the robot moves. That makes it an adverb.'}
    : {prompt:'Which sentence uses subject–verb agreement correctly?',choices:['The robots is dancing.','The robot are dancing.','The robots are dancing.','The robots has danced yesterday.'],answer:'The robots are dancing.',explanation:'Robots is plural, so it takes the verb are.'};}}
});

const SCREEN_TITLES = Object.freeze({homeScreen:'Welcome',activityScreen:'Activities',logicHubScreen:'Logic Lab',logicLabScreen:'Lost & Found',patternLabScreen:'Pattern Lab',shapeLabScreen:'Shape Lab',robotLabScreen:'Robot Rescue',slimeLabScreen:'Slime Sweeper',partsSpeechScreen:'Parts of Speech Lab',subjectScreen:'Choose a subject',battleScreen:'Brain Battle'});
const savedKey='brainrotAcademyGuideSeen_v1';
function seenGet(){try{return JSON.parse(localStorage.getItem(savedKey)||'{}')||{};}catch{return {};}}
function seenSet(k){try{const p=seenGet();p[k]=true;localStorage.setItem(savedKey,JSON.stringify(p));}catch{}}
export function createAcademyGuides({getGrade=()=>3,onOpen=()=>{},onClose=()=>{},welcome=()=>{}}={}){
  let active=null,step=0,answered=false,returnFocus=null;
  const root=document.createElement('div');root.id='academyGuideOverlay';root.className='academy-guide-overlay hidden';root.innerHTML=`<div class="academy-guide-dialog" role="dialog" aria-modal="true" aria-labelledby="academyGuideHeading" aria-describedby="academyGuideContent"><div class="academy-guide-head"><span id="academyGuideIcon" aria-hidden="true">🧠</span><div><small>PROFESSOR BRAINROT'S ACADEMY</small><h2 id="academyGuideHeading">HOW TO PLAY</h2></div><button id="academyGuideClose" class="academy-guide-close" type="button" aria-label="Close tutorial">✕</button></div><p id="academyGuideProgress" class="academy-guide-progress"></p><h3 id="academyGuideStep"></h3><p id="academyGuideContent"></p><p id="academyGuideExample" class="academy-guide-example hidden"></p><div id="academyGuideChoices" class="academy-guide-choices"></div><p id="academyGuideFeedback" role="status" aria-live="polite"></p><div class="academy-guide-actions"><button type="button" class="academy-guide-next" id="academyGuideNext">NEXT →</button></div></div>`;
  document.body.appendChild(root);
  const find=id=>root.querySelector('#'+id),next=find('academyGuideNext'),feedback=find('academyGuideFeedback'),choiceHost=find('academyGuideChoices');
  const lessonsHost=document.createElement('div');lessonsHost.className='academy-warmups';lessonsHost.id='academyWarmups';lessonsHost.innerHTML='<h3>📚 Learn it before you play</h3><p>Short guided lessons with an explanation and one practice question. No lives lost and no scores changed.</p><div class="academy-warmup-grid">'+Object.entries(LESSONS).map(([id,item])=>`<button type="button" data-academy-lesson="${id}">${item.icon} ${item.title} <span>LEARN →</span></button>`).join('')+'</div>';
  document.getElementById('subjectGrid')?.after(lessonsHost);
  lessonsHost.querySelectorAll('[data-academy-lesson]').forEach(b=>b.addEventListener('click',()=>openLesson(b.dataset.academyLesson)));
  for(const [screen,title] of Object.entries(SCREEN_TITLES)){
    const el=document.getElementById(screen);if(!el||screen==='homeScreen')continue;
    const btn=document.createElement('button');btn.type='button';btn.className='academy-help-pill';btn.setAttribute('aria-label',`How to play ${title}`);btn.textContent='❔ HOW TO PLAY';btn.addEventListener('click',()=>openGuide(screen));el.appendChild(btn);
  }
  function open(kind,id){
    if(active)return;
    returnFocus=document.activeElement;active={kind,id};step=0;answered=false;root.classList.remove('hidden');onOpen();render();find('academyGuideClose').focus();
  }
  function openGuide(id){if(GUIDES[id])open('guide',id);}
  function openLesson(id){if(LESSONS[id])open('lesson',id);}
  function close(){if(!active)return;const a=active;active=null;root.classList.add('hidden');onClose();if(returnFocus?.isConnected) returnFocus.focus();if(a.kind==='guide')seenSet(a.id);}
  function render(){
    if(!active)return;
    const data=active.kind==='guide'?GUIDES[active.id]:LESSONS[active.id];const lesson=active.kind==='lesson',total=data.steps.length+(lesson?1:0),quiz=lesson&&step===total-1;
    find('academyGuideIcon').textContent=data.icon;find('academyGuideHeading').textContent=data.title;
    find('academyGuideProgress').textContent=`${lesson?'GUIDED LESSON':'HOW TO PLAY'} · STEP ${step+1} OF ${total}`;
    const item=quiz?null:lesson?data.steps[step]:data.steps[step];
    find('academyGuideStep').textContent=quiz?'🎯 Check what you learned':lesson?item.title:item[0];
    find('academyGuideContent').textContent=quiz?data.question(getGrade()).prompt:lesson?item.text:item[1];
    find('academyGuideExample').classList.toggle('hidden',!lesson||quiz);
    find('academyGuideExample').textContent=lesson&&!quiz?`EXAMPLE: ${item.example}`:'';
    choiceHost.replaceChildren();feedback.textContent='';answered=false;
    if(quiz){const q=data.question(getGrade());for(const option of q.choices){const b=document.createElement('button');b.type='button';b.textContent=option;b.addEventListener('click',()=>{if(answered)return;
      if(option!==q.answer){feedback.textContent='Not quite. Try another answer!';feedback.className='academy-guide-feedback wrong';return;}
      answered=true;feedback.textContent='✅ Correct! '+q.explanation;feedback.className='academy-guide-feedback correct';choiceHost.querySelectorAll('button').forEach(x=>{x.disabled=true;x.classList.toggle('correct',x===b);});next.disabled=false;});choiceHost.appendChild(b);}}
    next.disabled=quiz;next.textContent=quiz?'FINISH LESSON ✓':step===total-1?'GOT IT ✓':'NEXT →';
  }
  function advance(){if(!active)return;const data=active.kind==='guide'?GUIDES[active.id]:LESSONS[active.id],total=data.steps.length+(active.kind==='lesson'?1:0);if(step<total-1){step++;render();}else{close();}}
  find('academyGuideClose').addEventListener('click',close);find('academyGuideNext').addEventListener('click',advance);
  root.addEventListener('keydown',event=>{if(event.key==='Escape'){event.preventDefault();close();}else if(event.key==='Tab'){
    const eligible=[...root.querySelectorAll('button:not([disabled]):not([hidden])')];if(!eligible.length)return;
    const first=eligible[0],last=eligible[eligible.length-1];if(event.shiftKey&&document.activeElement===first){event.preventDefault();last.focus();}else if(!event.shiftKey&&document.activeElement===last){event.preventDefault();first.focus();}
  }});
  return {openGuide,openLesson,close,isOpen:()=>Boolean(active),maybeStart(id){if(id==='activityScreen'&&!seenGet()[id]){openGuide(id);welcome();}else if(GUIDES[id]&&!seenGet()[id])openGuide(id);}};
}

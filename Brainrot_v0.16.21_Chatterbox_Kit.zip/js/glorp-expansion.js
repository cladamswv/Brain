// Generated from genuinely recorded local audio only. Empty until approved clips are supplied.
export const GLORP_EXPANSION = Object.freeze({});
export const GLORP_EXPANSION_OPENINGS = Object.freeze([]);

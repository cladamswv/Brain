## Additional v0.16.15 restoration

- Preserves original 217-source-file v0.16.9 content and restored 0.16.12 fixes. No original images, music, audio recordings, or game modes have been deleted.
- 10 tutorial entry screens available first visit and by on-screen HOW TO PLAY buttons; narrated and mobile-accessible.
- Added grade-adaptive Time, Calendar, and Grammar teaching with worked examples and a real practice challenge. This does not replace the original 8-part grammar course or alter mastery statistics.
- 50 local synthetic narrations in `assets/audio/tutorial/` include three grade-band variants for each practice question and one local intro. These are educational placeholder narrations, not an impersonation of the Professor.
- 11 local synthetic Glorp welcome variations, plus 12 local temporary synthetic Glorp reaction stand-ins in `assets/audio/voice/offline-reconstruction/` replace expired web URL dependencies and speak the correct line offline. They do **not** recreate the selected Grungle performance timbre. Original character audio preserved.
- Recorded authentic Grungle intro generated separately via Runway during restoration, but the returned audio bytes were not accessible to bundle. Do not claim this ZIP includes it.
- Automated tests cover the new features, but Android compilation and on-device smoke tests remain unverified.

# Professor Brainrot Academy full-source restoration

## Foundation and scope
The source comes from the user-supplied **v0.16.9 Codespaces Fresh Install** ZIP (7.2 MB). All existing assets, academic material, games, parts-of-speech course, PDF report, app ID, save keys, and Bantam startup sequence were preserved.

This is a **restored release candidate 0.16.12**, not a verified reconstruction of every detail of the former v0.16.10-0.16.14 historical builds.

## Implemented fixes beyond the v0.16.9 source
- Lost & Found: tap once to mark/unmark an X; double tap quickly on the same cell to search. Search button still supports immediate single-tap searching (also accessible to keyboard users). The pending single-tap timer is canceled on level restart and exit.
- Core Brain Battle/quiz and Logic Lab: Android Back closes an already open pause/exit overlay rather than reopening a modal or unintentionally leaving an activity.
- Normal difficulty introduces the first three questions at easier difficulty while preserving adaptive escalation.
- Refreshed Android build version, APK filename, offline cache identifier, and documentation.

## What the original v0.16.13/0.16.14 files are still needed for
Past discussions mentioned 11 new offline **Grungle/Glorp opening lines** and expanded spoken teaching for time, days, months and grammar. These recordings were not present in the uploaded v0.16.9 source and are **not** reproduced here. The original locally bundled Glorp audio and voice fallback routing still work. Bantam's black introductory loading screen already shipped in v0.16.9.

## Android install/save continuity
The package ID is `com.brainrotacademy.app`; prefs remain in the same localStorage keys. Updating an APK preserves saves only if the existing and new APK share the same Android signing certificate. If signatures differ, Android normally rejects an in-place update. Do not uninstall a saved installation without first making a backup.

## Build
```bash
npm ci
npm test
npm run android:build
```
Expected output: `artifacts/Brainrot_Academy_v0.16.12-debug.apk`.

## 15 October 2026 complete archive build correction
A previous source restoration ZIP inadvertently left out five original Android `resources/android/mipmap-*` launcher icons during ZIP assembly. This **COMPLETE** ZIP includes them again, byte-for-byte identical to the user's original v0.16.9 upload. The Android `scripts/configure-android.mjs` script explicitly needs these icons, so the earlier archive could fail at that step.

The archive has been freshly unpacked and tested, not merely tested in the development work directory. The JavaScript test suite, source integrity checks, `node --check`, and web packaging checks passed. Android Gradle compilation remains unverified locally.

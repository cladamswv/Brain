import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const text=fs.readFileSync('scripts/generate-glorp-chatterbox.py','utf8');
test('Chatterbox uses original Glorp voice as reference and official Nano API',()=>{
 assert.match(text,/audio_prompt_path=str\(ref\)/);
 assert.match(text,/ChatterboxTurboTTS\.from_pretrained/);
 assert.match(text,/nano=\(args\.model == 'nano'\)/);
});
test('Chatterbox staged voice previews cannot silently override game',()=>{
 assert.match(text,/voice_previews/);
 const s=fs.readFileSync('scripts/chatterbox-glorp.sh','utf8');
 assert.match(s,/mode.*install/);
 assert.match(s,/import-glorp-recordings/);
 assert.ok(fs.existsSync('voice_previews/chatterbox/glorp_reference.wav'));
});

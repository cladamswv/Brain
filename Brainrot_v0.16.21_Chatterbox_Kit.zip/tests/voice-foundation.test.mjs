import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {CHARACTER_VOICES, GLORP_PRODUCTION_LINES, GLORP_AUTHENTIC_OPENINGS, LEGACY_GLORP_FILES, getCharacterVoiceSource} from '../js/voice-registry.js';
import {glorpLines} from '../js/content.js';

const here=path.dirname(fileURLToPath(import.meta.url));
const root=path.resolve(here,'..');
const read=p=>fs.readFileSync(path.join(root,p),'utf8');

test('canonical character voices encode brother lore and distinct roles',()=>{
  assert.equal(CHARACTER_VOICES.professor.familyRole,'older-brother');
  assert.equal(CHARACTER_VOICES.professor.sibling,'glorp');
  assert.equal(CHARACTER_VOICES.professor.role,'teacher');
  assert.equal(CHARACTER_VOICES.glorp.familyRole,'younger-brother');
  assert.equal(CHARACTER_VOICES.glorp.sibling,'professor');
  assert.equal(CHARACTER_VOICES.glorp.providerVoice,'Grungle');
  assert.notEqual(CHARACTER_VOICES.professor.role,CHARACTER_VOICES.glorp.role);
});

test('unrecorded Glorp dialogue never plays unrelated audio',()=>{
  assert.equal(Object.keys(GLORP_PRODUCTION_LINES).length,0);
  for(const line of ['Easy. Obviously.','Fine. Maybe you are a little smart.','Professor! Make them less smart!']){
    assert.equal(getCharacterVoiceSource('glorp',line),null);
  }
});

test('all main rage banks and opening greetings speak their exact original lines',()=>{
  for(const bank of ['correct','wrong','angry','furious','meltdown']){
    assert.ok(glorpLines[bank].length>=3,`${bank} too small`);
    for(const line of glorpLines[bank]){
      assert.ok(LEGACY_GLORP_FILES[line],`${bank} has no word-for-word original Glorp recording: ${line}`);
      const voice=getCharacterVoiceSource('glorp',line);
      assert.equal(voice.file,LEGACY_GLORP_FILES[line]);
      assert.equal(voice.approximate,undefined);
    }
  }
  assert.ok(GLORP_AUTHENTIC_OPENINGS.length>=5);
  for(const line of GLORP_AUTHENTIC_OPENINGS)assert.ok(LEGACY_GLORP_FILES[line]);
});

test('Professor routing cannot silently use a Glorp or legacy narrator clip',()=>{
  assert.equal(getCharacterVoiceSource('professor','Stop knowing things!'),null);
  assert.equal(getCharacterVoiceSource('professor','Observe carefully, scholar.'),null);
  const audio=read('js/audio.js');
  const app=read('js/app.js');
  assert.match(audio,/speakCharacter\(speaker,text/);
  assert.doesNotMatch(app,/speakCharacter\('professor'/);
  assert.doesNotMatch(app,/function professorSay[^\n]+audio\.voice\(/);
});

test('voice manifest records Professor speech-bubble mode and retired spelling audio',()=>{
  const manifest=JSON.parse(read('assets/audio/voice/audio-migration-manifest.json'));
  assert.equal(manifest.build,'0.14.0');
  assert.equal(manifest.professorMode,'speech-bubbles-no-voice');
  assert.equal(manifest.spellingMode,'visual-four-choice-no-pronunciation');
  assert.equal(manifest.retiredLegacySpellingCount,153);
  assert.equal(manifest.spellingAudioRequired,false);
  assert.equal(manifest.productionGlorpBatchCount,12);
});

test('Professor is text-only while Glorp retains character voice routing',()=>{
  assert.equal(CHARACTER_VOICES.professor.status,'speech-bubble-only');
  assert.equal(CHARACTER_VOICES.professor.finalVoiceRequired,false);
  assert.equal(getCharacterVoiceSource('professor','Observe carefully, scholar.'),null);
  assert.equal(getCharacterVoiceSource('glorp','STOP KNOWING MATH!')?.type,'local-legacy');
});

import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import crypto from 'node:crypto';
import {glorpLines} from '../js/content.js';
import {GLORP_AUTHENTIC_OPENINGS, LEGACY_GLORP_FILES, getCharacterVoiceSource} from '../js/voice-registry.js';

const shaFile=file=>crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex');
const protectedHashes={
  'game-cheating.mp3':'c0a9279a236838f3d2b69415a9a75d830225e37abc9c84385e8a8025963348f5',
  'glorp-wins.mp3':'a97a61c1af347bbee24334bb41441300e51b7246b3fdd2c55ce4e60447560917',
  'grandpas-wifi.mp3':'e90781620fb45094166eaee29dc0a5dd4ca0b3be68a71990817827d80aedbb2c',
  'hotdog.mp3':'5346b4f475d72a8966612bba553804eaa10d9c152760f6d3e9aecf8743f9006a',
  'math-broken.mp3':'e45ff5ca701f2ea59f7ab382eb2fac614842068872ebcdb40d511db7955cb292',
  'potato.mp3':'631230c0cb5a210847508aa11f146510410183040ed7f0ab103b48eeb536da0f',
  'question-rigged.mp3':'94270286b504e9a21b3d191b2d76a77b077baae90425805fdd6ad21ef34e24ad',
  'stop-knowing-math.mp3':'13c5b0f05970afff4261c371c49298bcd10faaa3eafbbbe7a924b4a887cbc4e1',
  'watch-videos.mp3':'909013c2e9667008ae172f5d18d658b06617c9bb18b64d6a475659afbb177e33',
  'what-no.mp3':'8a469d82f7fa28e9ca044e46b99150e6134dbb66cd5c09479a7f32929ea02630'
};

test('original Glorp voice clips are preserved byte-for-byte',()=>{
 for(const [file,hash] of Object.entries(protectedHashes)){
  assert.equal(shaFile(`assets/audio/voice/${file}`),hash,`original Glorp voice changed: ${file}`);
 }
});
test('no robot-only Glorp files or runtime references survive',()=>{
 for(const p of ['assets/audio/voice/intro-reconstruction','assets/audio/voice/offline-reconstruction'])assert.equal(fs.existsSync(p),false,p);
 for(const p of ['js/app.js','js/audio.js','js/content.js','js/voice-registry.js','sw.js']){
  assert.doesNotMatch(fs.readFileSync(p,'utf8'),/intro-reconstruction|offline-reconstruction/,p);
 }
});
test('active main Glorp reaction banks always play original spoken phrases',()=>{
 for(const bank of ['correct','wrong','angry','furious','meltdown'])for(const phrase of glorpLines[bank]){
  assert.ok(LEGACY_GLORP_FILES[phrase],`no genuine voiced phrase: ${phrase}`);
  assert.equal(getCharacterVoiceSource('glorp',phrase).file,LEGACY_GLORP_FILES[phrase]);
 }
 for(const phrase of GLORP_AUTHENTIC_OPENINGS)assert.ok(LEGACY_GLORP_FILES[phrase]);
});

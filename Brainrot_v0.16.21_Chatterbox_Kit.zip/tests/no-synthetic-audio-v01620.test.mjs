import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {LEGACY_GLORP_FILES,getCharacterVoiceSource} from '../js/voice-registry.js';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const read=name=>fs.readFileSync(path.join(root,name),'utf8');
const exists=name=>fs.existsSync(path.join(root,name));
test('only established Glorp MP3 performances are kept in the spoken-voice directory',()=>{
 const mp3=fs.readdirSync(path.join(root,'assets/audio/voice')).filter(x=>x.endsWith('.mp3')).sort();
 const expected=[...new Set(Object.values(LEGACY_GLORP_FILES))].map(x=>path.basename(x)).sort();
 assert.deepEqual(mp3,expected);
 for(const [text,name] of Object.entries(LEGACY_GLORP_FILES)){
   assert.equal(getCharacterVoiceSource('glorp',text)?.file,name);
   assert.ok(fs.statSync(path.join(root,'assets/audio',name)).size>1000);
 }
});
test('no synthesized tutorial or reference clips or TTS engine are in the released app',()=>{
 for(const rel of ['assets/audio/tutorial','assets/audio/reference','www/assets/audio/tutorial','www/assets/audio/reference'])assert.equal(exists(rel),false,rel);
 for(const rel of ['index.html','js/app.js','js/audio.js','js/academy-guides.js','sw.js']){
   const content=read(rel);
   assert.doesNotMatch(content,/speechSynthesis|SpeechSynthesisUtterance|tutorialNarration|assets\/audio\/tutorial|guide-audio|academyGuideListen/i,rel);
 }
 assert.ok(read('index.html').includes('Original Glorp recordings'));
});
test('offscreen media is deferred to reduce initial mobile memory and media requests',()=>{
 assert.doesNotMatch(read('js/app.js'),/battleAssetUrls/);
 assert.doesNotMatch(read('js/audio.js'),/Object\.values\(LEGACY_GLORP_FILES\).*forEach/);
 assert.match(read('js/audio.js'),/preload='none'/);
 assert.match(read('index.html'),/loading="lazy" decoding="async"/);
});

test('upgrading over v0.16.19 deletes old generated audio but keeps Glorp',async()=>{
 const {execFileSync}=await import('node:child_process');
 const {mkdtempSync}=await import('node:fs');
 const {tmpdir}=await import('node:os');
 const fixture=mkdtempSync(path.join(tmpdir(),'academy-audio-clean-'));
 try {
   const original=path.join(fixture,'assets/audio/voice');fs.mkdirSync(original,{recursive:true});
   fs.writeFileSync(path.join(original,'hotdog.mp3'),'original glorp');
   fs.mkdirSync(path.join(fixture,'assets/audio/tutorial'),{recursive:true});
   fs.writeFileSync(path.join(fixture,'assets/audio/tutorial/guide-battleScreen-0.mp3'),'synthetic');
   fs.mkdirSync(path.join(fixture,'assets/audio/voice/intro-reconstruction'),{recursive:true});
   fs.writeFileSync(path.join(fixture,'assets/audio/voice/intro-reconstruction/glorp-intro-01.mp3'),'generated intro');
   fs.mkdirSync(path.join(fixture,'assets/audio/reference'),{recursive:true});
   fs.writeFileSync(path.join(fixture,'assets/audio/reference/professor-option1-necessary.mp3'),'unused sample');
   execFileSync(process.execPath,[path.join(root,'scripts/clean-robotic-glorp.mjs')],{cwd:fixture});
   assert.equal(fs.existsSync(path.join(fixture,'assets/audio/tutorial')),false);
   assert.equal(fs.existsSync(path.join(fixture,'assets/audio/reference')),false);
   assert.equal(fs.existsSync(path.join(fixture,'assets/audio/voice/intro-reconstruction')),false);
   assert.equal(fs.readFileSync(path.join(original,'hotdog.mp3'),'utf8'),'original glorp');
 } finally {fs.rmSync(fixture,{recursive:true,force:true});}
});

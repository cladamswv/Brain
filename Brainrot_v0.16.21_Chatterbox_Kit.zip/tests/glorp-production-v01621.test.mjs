import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {GLORP_EXPANSION, GLORP_EXPANSION_OPENINGS} from '../js/glorp-expansion.js';
import {getCharacterVoiceSource, GLORP_AUTHENTIC_OPENINGS} from '../js/voice-registry.js';
const manifest=JSON.parse(fs.readFileSync(new URL('../GLORP_VOICE_PRODUCTION_v0.16.21.json',import.meta.url),'utf8'));
test('voice-production queue is ready without fake recordings',()=>{
 assert.equal(manifest.lines.length,23);
 assert.equal(new Set(manifest.lines.map(x=>x.text)).size,23);
 assert.equal(manifest.approvedVoice,'Grungle');
 for(const item of manifest.lines){
  assert.ok(['pending','installed'].includes(item.status));
  if(item.status==='pending')assert.equal(getCharacterVoiceSource('glorp',item.text),null);
 }
});
test('every enabled expanded voice references local recorded MP3',()=>{
 for(const [text,file] of Object.entries(GLORP_EXPANSION)){
  assert.match(file,/^voice\/expansion\/[a-z0-9-]+\.mp3$/);
  assert.ok(fs.existsSync(new URL('../assets/audio/'+file,import.meta.url)),file);
  assert.equal(getCharacterVoiceSource('glorp',text).file,file);
 }
 for(const text of GLORP_EXPANSION_OPENINGS)assert.ok(GLORP_EXPANSION[text]);
 for(const text of GLORP_AUTHENTIC_OPENINGS)assert.ok(getCharacterVoiceSource('glorp',text));
});

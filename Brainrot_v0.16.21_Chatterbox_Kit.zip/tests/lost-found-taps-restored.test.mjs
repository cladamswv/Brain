import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {createTapActions} from '../js/tap-actions.js';

function harness(){
  const called=[],scheduled=new Map();let serial=0;
  const actions=createTapActions({onSingle:v=>called.push(['mark',v]),onDouble:v=>called.push(['search',v]),schedule:fn=>{const id=++serial;scheduled.set(id,fn);return id;},cancelScheduled:id=>scheduled.delete(id)});
  const advance=()=>{for(const [id,fn] of [...scheduled]){scheduled.delete(id);fn();}};
  return {actions,called,advance};
}
test('single tap marks only after double-tap window',()=>{
  const x=harness();x.actions.tap('1,2','1,2');assert.deepEqual(x.called,[]);x.advance();assert.deepEqual(x.called,[['mark','1,2']]);
});
test('double tap searches without placing a marker',()=>{
  const x=harness();x.actions.tap('1,2','1,2');x.actions.tap('1,2','1,2');x.advance();assert.deepEqual(x.called,[['search','1,2']]);
});
test('taps on different cells do not search either cell',()=>{
  const x=harness();x.actions.tap('1,2','1,2');x.actions.tap('1,3','1,3');x.advance();assert.deepEqual(x.called,[['mark','1,2'],['mark','1,3']]);
});
test('exiting an activity cancels a queued single tap',()=>{
  const x=harness();x.actions.tap('1,2','1,2');x.actions.cancel();x.advance();assert.deepEqual(x.called,[]);
});
test('original five logic games and pause wiring remain in the app',()=>{
  const source=fs.readFileSync(new URL('../js/app.js',import.meta.url),'utf8');
  for(const name of ['openLostFound','openPatternLab','openShapeLab','openRobotRescue','openSlimeSweeper','resumeCoreGame','resumeLogicGame']) assert.ok(source.includes(name));
  assert.ok(source.includes('handleLogicCellTap(row,col,cell)'));
  assert.ok(source.includes("mode:'mark',found:new Set()"));
});

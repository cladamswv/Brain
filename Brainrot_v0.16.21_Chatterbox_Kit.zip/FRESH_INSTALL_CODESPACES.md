# Fresh install v0.16.21

See [CODESPACES_START_HERE.md](CODESPACES_START_HERE.md).

Upload the complete `Brainrot_v0.16.21.zip` once, extract it in your repository, then execute `bash scripts/codespaces-build.sh`. This recreates `www/` and `android/`, removes synthetic audio left by earlier releases, installs dependencies, runs tests, and builds the APK.

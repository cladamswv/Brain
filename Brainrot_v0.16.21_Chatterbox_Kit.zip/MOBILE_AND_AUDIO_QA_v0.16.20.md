# Brainrot Academy v0.16.20 | Mobile and original-audio verification

- Preserves exactly the 10 original Glorp performances from the earlier source with SHA-256 equality assertions.
- Removes all 50 synthetic tutorial narration MP3s and the unused synthetic Professor reference from the shipped source and Android web bundle.
- Removes text-to-speech controls and playback routes; tutorials remain **offline text with interactive practice**.
- Unrecorded Glorp dialogue remains written-only, never voiced by a substitute or unrelated clip.
- Reduces boot-time media setup by using on-demand audio, defers non-home artwork decoding, and shortens artificial splash delay.
- Mobile layout remains portrait-first, with stacked answers, compact HUD, and no floating help overlap.
- Offline cache regenerated; old cache versions are discarded upon service worker activation.
- Android build uses Java 21 and Capacitor 8; same app ID to allow updates with matching signing key.

## Validation boundary
Automated tests and browser viewport checks validate source behaviour. Real Android WebView, device performance, offline/airplane-mode, and actual APK build still require Codespaces and a phone smoke test.

## Mobile runtime verification
- JavaScript syntax checks and offline contract tests pass.
- Full source tests include the 10 source-matched Glorp SHA-256 clips, cached local assets, launcher icons, build tooling, and synthetic-audio upgrade cleanup.
- The previous v0.16.19 UI was checked at 320, 360, 393, 412, 768 and 844 px; this revision preserves those layout rules.
- Current-turn automated browser navigation was blocked by environment access policy; do not treat viewport/source tests as proof of device performance.

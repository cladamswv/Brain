# Professor Brainrot Academy 0.16.18: Mobile-first release

## What changed

- New `mobile-first.css` design layer, loaded last, overrides conflicting legacy breakpoints on phones and small tablets while preserving the older wide-screen presentation.
- Android battle / quiz / pizza / milkshake screens use a compact two-row action bar, stacked HP meter, short Glorp stage, readable full-width prompt, and a vertical list of answer choices. Natural-height text wraps instead of clipping.
- Original game-specific numeric input, missing-letter and letter-build controls retain their separate layouts and touch interactions.
- The tutorial **How to Play** control is now in normal scroll flow on mobile, never over the fourth answer choice. Next Question similarly stops covering answer choices.
- Grade selection, game selection, Logic Lab, puzzle boards, Parent Progress and guided tutorials are constrained to portrait widths. All screens scroll vertically when necessary; the Android safe area and bottom dock are accounted for.
- 100% text size adjustment prevents unexpected browser text inflation; mobile action buttons remain at least roughly 44px tall, with most answers at 58px or more.
- Original app package ID (`com.brainrotacademy.app`) and progress-storage implementation are unchanged. Android `versionCode=1618` and `versionName=0.16.18` support an in-place upgrade when the signing key matches.
- Original Glorp audio routing and bundled music, art, games and offline content are preserved. This release does **not** fabricate missing additional Glorp recordings.
- Cache version refreshed and new style included in service-worker pre-cache and Capacitor web bundle.

## Testing and verification

- Existing automated JS gameplay, offline, Android-configuration and audio tests plus new mobile layout contract tests run with `npm test`.
- Representative **static DOM rendering** checks were performed with headless Chromium at 320×700, 360×780, 393×852, 412×915, 768×1024 and 844×390 viewport pixels, using actual `index.html` and actual stylesheets with representative battle vocabulary text. No horizontal overflow or clipped answer text in those checks; the help button was verified to be non-floating. The home and activity layouts were also inspected at 360×780.
- This is not the same as a device-side end-to-end gameplay test. The Android APK build and real touchscreen / accessibility behavior must be checked in Codespaces and on a phone.

## Build

Upload the complete ZIP to GitHub Codespaces, unzip into the repository root, and run `bash scripts/codespaces-build.sh` (Java 21 and Android SDK 36). Output: `artifacts/Brainrot_Academy_v0.16.18-debug.apk`.

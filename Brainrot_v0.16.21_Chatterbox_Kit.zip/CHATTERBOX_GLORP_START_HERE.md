# Chatterbox voice production for Glorp (free, local generation)

This add-on keeps **all existing original Glorp recordings**, the **mobile-first layout**, and the **offline game** unchanged. It uses Chatterbox's open-source **Nano model** on the Codespaces CPU to create *new* candidate dialogue, conditioned on about 9 seconds of existing Glorp MP3s. It does not use a hosted TTS API.

## First: test one voice sample

1. Download this complete project ZIP; upload it to the **root** of Codespaces, not `artifacts`.
2. Unzip it. Run:

```bash
bash scripts/chatterbox-glorp.sh sample
```

The first run downloads dependencies and open model weights; an internet connection is required for *recording production*, not for the finished Android game. Generated audio lands at `voice_previews/chatterbox/intro-01.mp3`. Right-click it in Codespaces and choose Download to listen.

If the test voice doesn't match Glorp, **do not install it**. Nano voice resemblance varies. You can optionally run with a GPU-equipped environment and `CHATTERBOX_MODEL=turbo` for higher quality, but that is not guaranteed to sound identical.

## After you approve the voice sample

```bash
bash scripts/chatterbox-glorp.sh all
bash scripts/chatterbox-glorp.sh install
bash scripts/codespaces-build.sh
```

The `all` command produces the 23 candidate MP3s, and `install` copies them into the offline game and updates the voice registry. The game then bundles the audio in the APK. `all` skips already-made files so a failed or disconnected session can resume.

**Please check permissions** for using existing recordings as cloning reference, especially if this game will be commercial. Chatterbox is open-source and MIT-licensed, but that does not grant rights to reproduce a third-party proprietary voice. No new recordings have been produced inside this ZIP; this release contains a working *generation workflow*, not fabricated results.

If Codespaces has inadequate memory/CPU, run these same scripts on a machine with more resources. The provided installer uses CPU PyTorch; using a GPU requires installing GPU-enabled PyTorch separately. The finished game remains offline; Chatterbox is never included in the APK.

Chatterbox official repository: https://github.com/resemble-ai/chatterbox
